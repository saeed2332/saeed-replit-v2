"""
Persistent vector memory for Saeed‑Replit agents.

This module wraps a ChromaDB persistent store and exposes a small API
for adding and querying textual memories.  Embeddings are computed
using a sentence‑transformer model.  When the underlying schema
changes and causes ChromaDB to throw an exception during client
construction, the existing store is automatically wiped and
reinitialized.

Usage:

    from vector_memory import VectorMemory
    vm = VectorMemory()
    vm.add("greeting", "hello world")
    similar_docs = vm.query("hi there", k=5)
"""
from __future__ import annotations

import os
import shutil
from typing import Iterable, List

import chromadb
from chromadb import PersistentClient
from chromadb.utils import embedding_functions


def _safe_chroma_client(persist_dir: str) -> PersistentClient:
    """Return a ChromaDB client, rebuilding the store if necessary.

    ChromaDB occasionally breaks compatibility across versions.  When
    this happens the underlying SQLite schema may no longer match the
    expectations of the installed client and an exception will be
    raised.  To keep the developer workflow simple this helper
    catches any exception on client construction, removes the
    persistent directory and retries once.  This effectively wipes
    the store but allows the application to proceed without manual
    intervention.
    """
    try:
        return PersistentClient(path=persist_dir)
    except Exception as exc:
        print(f"⚠️  ChromaDB schema mismatch – wiping store: {exc}")
        shutil.rmtree(persist_dir, ignore_errors=True)
        return PersistentClient(path=persist_dir)


class VectorMemory:
    """Wrapper around a ChromaDB collection for storing text embeddings."""

    def __init__(self, persist_dir: str = ".vector_store", collection_name: str = "memory") -> None:
        self._client = _safe_chroma_client(persist_dir)
        self._collection = self._client.get_or_create_collection(collection_name)
        # Use a small but effective model for embeddings.  See
        # https://www.sbert.net/docs/pretrained_models.html for alternatives.
        self._embed = embedding_functions.SentenceTransformerEmbeddingFunction(
            model_name="sentence-transformers/all-MiniLM-L6-v2"
        )

    def add(self, key: str, text: str) -> None:
        """Add a document to the store keyed by ``key``.

        If the given key already exists in the collection it will be
        updated with the new text.  Embeddings are computed
        immediately.
        """
        try:
            embedding = self._embed([text])
            self._collection.add(
                ids=[key], documents=[text], embeddings=embedding
            )
        except Exception as exc:
            # Chroma suppresses many errors internally; we log
            print(f"Failed to add document to vector store: {exc}")

    def query(self, query_text: str, k: int = 5) -> List[str]:
        """Return up to ``k`` documents most similar to ``query_text``.

        If the collection is empty or an error occurs an empty list is
        returned.  Only the document contents are returned – if the
        caller needs ids or distances they should interact with the
        collection directly.
        """
        try:
            result = self._collection.query(query_texts=[query_text], n_results=k)
            docs: Iterable[str] = result.get("documents", [[]])[0]
            return list(docs)
        except Exception as exc:
            print(f"Vector store query failed: {exc}")
            return []