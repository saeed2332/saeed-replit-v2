# Saeed‑Replit

Saeed‑Replit is a self‑improving development agent built on top of
Microsoft's AutoGen framework.  It brings together several tools –
a shell runner, file management, persistent vector memory, web
search and planning – to create a multi‑agent environment capable
of writing and modifying code, running tests, remembering past
context and suggesting next steps.

## Quick start

1. **Create and activate a virtual environment**

```bash
python3 -m venv venv --upgrade-deps
source venv/bin/activate
```

2. **Install dependencies**

```bash
pip install -r requirements.txt
```

3. **Export your API keys**

At least one API key is required to run the agent.  Set either
`OPENAI_API_KEY` (for GPT‑4o models) or `XAI_API_KEY` (for
Grok‑4) in your shell environment:

```bash
export OPENAI_API_KEY=sk-your-openai-key
# optionally
export XAI_API_KEY=sk-xai-key
```

4. **Run a smoke test**

To verify that the environment and code are set up correctly, run
the test suite:

```bash
python agent_runner.py
```

You should see a single green dot indicating success.

5. **Execute shell commands**

You can run arbitrary shell commands through the agent runner by
passing the command as an argument:

```bash
python agent_runner.py "echo hello world"
```

## Chat interface

Launch the Streamlit UI to chat with the agent in your browser:

```bash
streamlit run chat_with_agent.py \
  --server.port 8501 --server.address 0.0.0.0 \
  --server.headless true --server.enableCORS false \
  --server.enableXsrfProtection false
```

Then open the provided URL (e.g. `http://localhost:8501`) to start a
conversation.  The chat interface supports basic tool calls like
listing files, reading and writing files, running shell commands and
performing web searches (when configured with a Bing API key).

## Planner

The `planner.py` script implements a minimalist Phase 10 loop.  It
examines the repository state, asks the agent for one next task, and
records the task into `TODO.md` along with a one‑line reason.  It
then commits the change and attempts to push it upstream.  You can
run the planner manually or schedule it via cron or a job runner.

## Contributing

This project is intended as a learning tool.  Contributions are
welcome – please open an issue or pull request with your ideas!