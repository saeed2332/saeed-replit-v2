"""
Streamlit chat interface for the Saeed‑Replit dev agent.

This script launches a simple Streamlit app that allows users to
converse with the development agent defined in the Saeed‑Replit
project.  The same underlying agent and tools used by the CLI are
exposed via a web form.  Messages entered by the user are sent to
the agent and the agent's response is rendered below the input.

To run the app from your terminal, activate your virtual environment
and execute:

    streamlit run chat_with_agent.py --server.port 8501 \
      --server.address 0.0.0.0 --server.headless true \
      --server.enableCORS false --server.enableXsrfProtection false

You can then open the provided URL in your browser to chat with
the agent.
"""
from __future__ import annotations

import streamlit as st
# Import the AG1 agent classes from ``autogen``.  We intentionally pin
# pyautogen to the 0.2.x series in requirements.txt because later
# versions remove the ``llm_config`` parameter from these constructors.
from autogen import AssistantAgent, UserProxyAgent  # type: ignore

from utils import load_llm_config
from file_manager import list_dir, read_file, write_file
from vector_memory import VectorMemory
from web_search_tool import search_web


def build_agent() -> AssistantAgent:
    """
    Construct and configure the development agent for the chat UI.

    This helper creates an instance of ``AssistantAgent`` configured
    using the current LLM settings and registers a suite of tools.  It
    also attaches a persistent vector memory store to the agent to
    support memory queries and additions via the sidebar.
    """
    llm_config = load_llm_config()
    # Instantiate the assistant agent using the legacy AG1 API.  This API
    # accepts an ``llm_config`` dict on construction to configure
    # OpenAI or other model providers.  If AG1 is not available the
    # import fallback at the top of this file will import an AG2 agent
    # which does not accept ``llm_config`` and will raise a TypeError.
    dev = AssistantAgent(name="dev", llm_config=llm_config)
    # Register basic I/O tools
    dev.register_function(list_dir, name="list_dir", description="List files in a directory")
    dev.register_function(read_file, name="read_file", description="Read file contents")
    dev.register_function(write_file, name="write_file", description="Write contents to a file")
    # Shell runner
    def run_shell(command: str) -> str:
        import subprocess
        completed = subprocess.run(command, shell=True, text=True, capture_output=True)
        return completed.stdout + f"\nRETURN_CODE:{completed.returncode}"
    dev.register_function(run_shell, name="run_shell", description="Run a shell command")
    # Web search
    dev.register_function(search_web, name="search_web", description="Search the web")
    # Attach a vector memory to the agent instance.  The memory object
    # is stored on the agent so that the UI sidebar can access it via
    # ``st.session_state['dev_agent']._memory``.  These functions wrap
    # calls into the memory and are registered as tools.
    dev._memory = VectorMemory()
    def add_memory(key: str, text: str) -> str:
        dev._memory.add(key, text)
        return "OK"
    def query_memory(query: str, k: int = 3) -> list[str]:
        return dev._memory.query(query, k)
    dev.register_function(add_memory, name="add_memory", description="Add text to vector memory")
    dev.register_function(query_memory, name="query_memory", description="Query vector memory for similar texts")
    return dev


st.set_page_config(page_title="Saeed‑Replit Chat", page_icon="💬", layout="centered")
st.title("Saeed‑Replit Dev Agent Chat")

# -----------------------------------------------------------------------------
# Sidebar: display model info, memory operations, and run quick actions.
sidebar = st.sidebar
sidebar.title("Agent Tools & Memory")

# Show which model is in use and whether an API key is present.
with sidebar.expander("LLM Info", expanded=False):
    cfg = load_llm_config()
    cfg_entry = cfg.get("config_list", [{}])[0]
    model_name = cfg_entry.get("model", "(unknown)")
    key_present = bool(cfg_entry.get("api_key"))
    sidebar.markdown(f"**Model:** {model_name}")
    sidebar.markdown(f"**API key present:** {key_present}")

# Add memory section
sidebar.subheader("Add to Memory")
mem_key = sidebar.text_input("Memory key", key="mem_key")
mem_text = sidebar.text_area("Memory content", key="mem_text")
if sidebar.button("Add Memory"):
    if mem_key and mem_text:
        dev_agent = st.session_state.get("dev_agent")
        if dev_agent is not None:
            dev_agent._memory.add(mem_key, mem_text)
            sidebar.success(f"Added memory under key '{mem_key}'")
    else:
        sidebar.warning("Please provide both a key and content.")

# Query memory section
sidebar.subheader("Query Memory")
mem_query = sidebar.text_input("Query text", key="mem_query")
mem_k = sidebar.number_input("Top K results", min_value=1, max_value=10, value=3, step=1, key="mem_k")
if sidebar.button("Search Memory"):
    if mem_query:
        dev_agent = st.session_state.get("dev_agent")
        if dev_agent is not None:
            results = dev_agent._memory.query(mem_query, int(mem_k))
            if results:
                sidebar.markdown("**Results:**")
                for i, r in enumerate(results, 1):
                    sidebar.write(f"{i}. {r}")
            else:
                sidebar.info("No matches found.")
    else:
        sidebar.warning("Please enter a query.")

# Action buttons
sidebar.subheader("Quick Actions")
if sidebar.button("Run Smoke Tests"):
    import subprocess, sys
    sidebar.write("Running smoke tests…")
    result = subprocess.run([sys.executable, "agent_runner.py"], capture_output=True, text=True, cwd=".")
    sidebar.text(result.stdout)
    if result.returncode == 0:
        sidebar.success("Tests passed!")
    else:
        sidebar.error("Tests failed.")
if sidebar.button("Run Planner"):
    import subprocess, sys
    sidebar.write("Running planner…")
    result = subprocess.run([sys.executable, "planner.py"], capture_output=True, text=True, cwd=".")
    sidebar.text(result.stdout)
    if result.returncode == 0:
        sidebar.success("Planner executed!")
    else:
        sidebar.error("Planner encountered an error.")

# Initialize the agent once per session
if "dev_agent" not in st.session_state:
    st.session_state["dev_agent"] = build_agent()
    st.session_state["user_agent"] = UserProxyAgent(
        name="user", code_execution_config=False, llm_config=load_llm_config()
    )

dev_agent: AssistantAgent = st.session_state["dev_agent"]
user_agent: UserProxyAgent = st.session_state["user_agent"]

# Conversation history stored as a list of (role, message) tuples
if "history" not in st.session_state:
    st.session_state["history"] = []

# Render chat history
for role, msg in st.session_state["history"]:
    if role == "user":
        st.chat_message("user").write(msg)
    else:
        st.chat_message("assistant").write(msg)

# Input box for user
prompt = st.chat_input("Enter a message and press Enter…")
if prompt:
    # Append user message to history
    st.session_state["history"].append(("user", prompt))
    st.chat_message("user").write(prompt)
    # Ask the agent for a response
    # We use initiate_chat to send a new message to the dev agent.
    result = user_agent.initiate_chat(dev_agent, message=prompt)
    # Extract the assistant's latest response from result.messages
    # In newer versions of AutoGen, result is a TaskResult with a messages list.
    try:
        messages = result.messages  # type: ignore[attr-defined]
    except AttributeError:
        # Fallback: if result itself is the content
        messages = [result]
    # The last message should be the assistant's final response
    assistant_content = ""
    for m in messages[::-1]:
        # Autogen messages may be simple dicts or TextMessage objects
        content = getattr(m, "content", None) or (m if isinstance(m, str) else None)
        source = getattr(m, "source", None) or "assistant"
        if source == "assistant" and content:
            assistant_content = content
            break
    if not assistant_content:
        assistant_content = "(no response)"
    # Append assistant's reply to history and display it
    st.session_state["history"].append(("assistant", assistant_content))
    st.chat_message("assistant").write(assistant_content)