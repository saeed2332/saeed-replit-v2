"""
File management helpers for Saeed‑Replit.

These small helper functions provide a thin abstraction over Python's
filesystem primitives.  They are designed to be registered as
AutoGen tools so that an agent can inspect and manipulate files in
the working directory.  When used directly from the command line
they return plain strings rather than raising exceptions.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Iterable, Optional


def list_dir(path: str = ".", recursive: bool = False) -> str:
    """Return a newline‑separated list of files in ``path``.

    If ``recursive`` is true the entire tree rooted at ``path`` is
    enumerated.  Otherwise only the immediate children are listed.
    The function returns a string so it can be returned directly
    from an AutoGen tool.  Errors are captured and reported in the
    returned value rather than raising.
    """
    p = Path(path).expanduser()
    if not p.exists():
        return f"{path} does not exist"
    try:
        if recursive:
            files: Iterable[Path] = p.rglob("*")
            items = [str(f.relative_to(p)) for f in files]
        else:
            files = p.iterdir()
            items = [f.name for f in files]
        return "\n".join(items)
    except Exception as exc:
        return f"Error listing {path}: {exc}"


def read_file(path: str) -> str:
    """Read and return the contents of the file at ``path``.

    Returns the file contents on success.  On failure the returned
    string contains an error message.  The caller is responsible for
    providing a correct relative or absolute path.
    """
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception as exc:
        return f"Error reading {path}: {exc}"


def write_file(path: str, content: str) -> str:
    """Write ``content`` to the file at ``path``, creating parent directories.

    The function returns a short confirmation string on success or an
    error description on failure.  If the parent directory does not
    exist it is created automatically.
    """
    try:
        p = Path(path)
        parent = p.parent
        if parent and not parent.exists():
            parent.mkdir(parents=True, exist_ok=True)
        with open(p, "w", encoding="utf-8") as f:
            f.write(content)
        return f"Wrote {len(content)} characters to {path}"
    except Exception as exc:
        return f"Error writing to {path}: {exc}"