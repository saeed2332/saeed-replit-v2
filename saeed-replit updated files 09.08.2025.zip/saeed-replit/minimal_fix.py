"""
Minimal self‑healing execution helper.

This module contains a very simple wrapper to run Python code and
attempt to handle `NameError` exceptions gracefully.  The intent is
to provide a hook for a future extension where the agent can call
back into a language model to resolve missing imports or other
typos.  At present this function only returns an error message when
an exception occurs.
"""
from __future__ import annotations

import traceback


def minimal_run(code: str) -> str:
    """Execute arbitrary Python code and return the output or an error.

    The supplied string is executed in a fresh local namespace.  If
    execution completes without raising an exception the function
    returns ``"Executed successfully."``.  If a `NameError` is
    raised the function returns a message that includes the error
    text.  Any other exception results in a formatted traceback.
    """
    local_ns = {}
    try:
        exec(code, {}, local_ns)
        return "Executed successfully."
    except NameError as exc:
        return f"NameError encountered: {exc}"
    except Exception:
        return traceback.format_exc()