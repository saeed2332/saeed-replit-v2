"""
Simple web search helper for Saeed‑Replit.

This module defines a very lightweight wrapper around either the
Bing Web Search API or a stubbed fallback implementation.  The
preferred way of enabling real search is to set the environment
variables ``BING_SUBSCRIPTION_KEY`` and ``BING_SEARCH_ENDPOINT`` to
valid values.  When these variables are present the ``search_web``
function will make an HTTP request to Bing's REST API and return the
top results.  In all other cases it will return a trivial result
explaining that real search is unavailable.

The return value of ``search_web`` is a list of dictionaries, each
with ``title``, ``snippet`` and ``url`` keys.  This shape is
expected by AutoGen when the function is registered as a tool.
"""
from __future__ import annotations

import os
import requests
from typing import Dict, List


def _bing_request(term: str, top_k: int = 5) -> Dict:
    """Internal helper to query the Bing Web Search API."""
    key = os.getenv("BING_SUBSCRIPTION_KEY")
    endpoint = os.getenv(
        "BING_SEARCH_ENDPOINT", "https://api.bing.microsoft.com/v7.0/search"
    )
    if not key:
        raise RuntimeError(
            "BING_SUBSCRIPTION_KEY is not set – real search is unavailable"
        )
    headers = {"Ocp-Apim-Subscription-Key": key}
    params = {
        "q": term,
        "textDecorations": True,
        "textFormat": "HTML",
        "count": top_k,
    }
    response = requests.get(endpoint, headers=headers, params=params, timeout=10)
    response.raise_for_status()
    return response.json()


def search_web(query: str, k: int = 5) -> List[Dict[str, str]]:
    """Search the web and return a list of search results.

    Each result is a dict with ``title``, ``snippet`` and ``url`` keys.  If the
    Bing API is not configured this function will return a single
    entry explaining that search is unavailable.  Any HTTP errors
    raised by the requests library are propagated to the caller.
    """
    # If a Bing subscription key is configured use real search
    if os.getenv("BING_SUBSCRIPTION_KEY"):
        try:
            data = _bing_request(query, top_k=k)
            web_pages = data.get("webPages", {}).get("value", [])
            results: List[Dict[str, str]] = []
            for page in web_pages:
                results.append(
                    {
                        "title": page.get("name", ""),
                        "snippet": page.get("snippet", ""),
                        "url": page.get("url", ""),
                    }
                )
            return results
        except Exception as exc:
            return [
                {
                    "title": "Search error",
                    "snippet": str(exc),
                    "url": "",
                }
            ]
    # Fallback stub
    return [
        {
            "title": "Web search disabled",
            "snippet": "Real search is unavailable because no API key is configured.",
            "url": "",
        }
    ]