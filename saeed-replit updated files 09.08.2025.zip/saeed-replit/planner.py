"""
Simple project planner for Saeed‑Replit.

This script demonstrates a rudimentary Phase 10 loop: it inspects
the current repository state, prompts the development agent to
propose exactly one concrete next task, appends that task and its
reasoning to a ``TODO.md`` file, commits the change and pushes it
to the default remote.  The planner can be scheduled to run
periodically via cron or a job runner to continually advance the
project without manual oversight.
"""
from __future__ import annotations

import subprocess
import pathlib
from autogen import AssistantAgent, UserProxyAgent

from utils import load_llm_config


def git(*args: str) -> str:
    """Run a git command and return its output as a string."""
    return subprocess.check_output(["git", *args], text=True).strip()


def main() -> None:
    repo = pathlib.Path(__file__).resolve().parent
    todo_path = repo / "TODO.md"

    # Gather repository status
    try:
        status = git("status", "-s")
    except Exception as exc:
        print(f"git status failed: {exc}")
        status = "(unknown)"

    existing = ""
    if todo_path.exists():
        try:
            existing = todo_path.read_text(encoding="utf-8")[:1000]
        except Exception:
            existing = "(unable to read TODO.md)"
    else:
        existing = "(none)"

    # Construct prompt for the agent
    prompt = (
        "You are the project planner for Saeed‑Replit. "
        "Given the current git status and the existing TODO list, "
        "propose exactly ONE concrete next task (a short imperative) and a one‑line reasoning.\n"
        f"Current `git status -s`:\n{status}\n\nExisting TODO.md (first 1000 characters):\n{existing}\n"
    )

    llm_config = load_llm_config()
    dev = AssistantAgent(name="dev", llm_config=llm_config)
    pm = UserProxyAgent(name="planner", code_execution_config=False, llm_config=llm_config)
    # Ask the dev agent for the next task
    result = pm.initiate_chat(dev, message=prompt)
    # Attempt to extract the assistant's reply.  See chat_with_agent for similar logic.
    try:
        messages = result.messages  # type: ignore[attr-defined]
    except AttributeError:
        messages = [result]
    response = ""
    for m in messages[::-1]:
        content = getattr(m, "content", None) or (m if isinstance(m, str) else None)
        source = getattr(m, "source", None) or "assistant"
        if source == "assistant" and content:
            response = content
            break
    if not response:
        print("No response from agent")
        return
    # Split into task and reason
    lines = [l.strip() for l in response.splitlines() if l.strip()]
    task = lines[0] if lines else "Unspecified task"
    reason = lines[1] if len(lines) > 1 else ""
    # Append to TODO.md
    with open(todo_path, "a", encoding="utf-8") as f:
        f.write(f"- [ ] {task}\n    {reason}\n")
    try:
        git("add", str(todo_path))
        git("commit", "-m", f"planner: {task[:72]}")
        # Push may fail if no remote is configured; ignore errors
        try:
            git("push")
        except Exception:
            pass
    except Exception as exc:
        print(f"Failed to commit planner update: {exc}")


if __name__ == "__main__":
    main()