"""
Utility functions for the Saeed‑Replit dev agent.

This module contains small helpers used across the project. The most
important function provided here is `load_llm_config()`, which
constructs the configuration dictionary expected by AutoGen when
instantiating agents.  The function automatically chooses between
OpenAI and XAI (Grok) endpoints based on which API key is present in
the environment.  If neither key is available, an informative
exception is raised.
"""
from __future__ import annotations

import os


def load_llm_config() -> dict:
    """Return a minimal LLM configuration for AutoGen agents.

    The configuration consists of a list of dicts under the
    ``config_list`` key.  Each dict describes a single model
    endpoint.  This helper inspects environment variables to decide
    which API to use.  If ``XAI_API_KEY`` is present the agent will
    target Grok‑4 via that key; otherwise it falls back to
    ``OPENAI_API_KEY`` and uses the ``gpt‑4o‑mini`` model.  If
    neither environment variable is defined, a ``RuntimeError`` is
    raised.

    The returned dict is intentionally minimal – additional keys such
    as ``temperature`` or ``max_tokens`` may be specified by the
    caller if desired.
    """
    xai_key = os.getenv("XAI_API_KEY")
    openai_key = os.getenv("OPENAI_API_KEY")
    if xai_key:
        # When an XAI key is provided we assume Grok‑4 is available via
        # the XAI API.  AutoGen will internally map the ``api_key``
        # field to the appropriate client.
        model = "grok-4"
        api_key = xai_key
    elif openai_key:
        # Default to the lightweight GPT‑4o variant when only an OpenAI key
        # is present.  Users may override this by exporting a different
        # ``MODEL_NAME`` environment variable if required.
        model = os.getenv("MODEL_NAME", "gpt-4o-mini")
        api_key = openai_key
    else:
        raise RuntimeError(
            "No API key found.  Please set either XAI_API_KEY or OPENAI_API_KEY."
        )
    return {
        "config_list": [
            {
                "model": model,
                "api_key": api_key,
            }
        ]
    }